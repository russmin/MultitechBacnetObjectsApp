README!

To install the BacnetObjects app. 
1. Choose the correct app version for you opetating system.
MTCDT/MTCAP -->arm9 version
MTCAP3 --> arm7 version

2. Make sure your conduit has internet access so the app can install the reuired python libraries.

3. Go to the Custom Apps page on the conduit

Enter app id of your choose
Enter the name of the app "BacnetObjects"

The case and spelling is important. 

4. Choose the file in you machine

submit. 
* the download will take ~10min
